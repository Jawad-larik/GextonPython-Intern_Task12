# 🧠 AI-Based Resume Screening System

This is a Streamlit-based web app that allows you to upload a job description and multiple resumes (PDF/DOCX). It uses AI (BERT embeddings) to rank the resumes based on their similarity to the job description.

## 🚀 Features
- Upload multiple resumes (.pdf/.docx)
- Upload job description (.txt)
- Extract and compare resume content semantically
- Extract sections: Skills, Education, Experience
- Display and download ranked results

## 📦 Installation
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 📁 Input Format
- Job Description: `.txt`
- Resumes: `.pdf` or `.docx`

## 📤 Output
- Ranked CSV file with match scores and extracted sections

---

**Developed by Jawad Larik**