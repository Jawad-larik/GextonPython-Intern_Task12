import streamlit as st
import os
import fitz  # For PDF reading
import docx  # For DOCX reading
import re
import pandas as pd
import nltk
from nltk.corpus import stopwords
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import tempfile

nltk.download('stopwords')

# -------------------------------
# Helper Functions
# -------------------------------

def extract_text_pdf(file_path):
    doc = fitz.open(file_path)
    text = ''
    for page in doc:
        text += page.get_text()
    return text

def extract_text_docx(file_path):
    doc = docx.Document(file_path)
    return '\n'.join([para.text for para in doc.paragraphs])

def clean_text(text):
    text = re.sub(r'\s+', ' ', text.lower())
    stop_words = set(stopwords.words('english'))
    return ' '.join([word for word in text.split() if word not in stop_words])

def extract_resume_sections(text):
    sections = {"skills": "", "education": "", "experience": ""}
    lines = text.lower().splitlines()
    current = None
    for line in lines:
        if "skill" in line:
            current = "skills"
        elif "education" in line:
            current = "education"
        elif "experience" in line or "work" in line:
            current = "experience"
        elif line.strip() == "":
            current = None
        elif current:
            sections[current] += " " + line.strip()
    for key in sections:
        sections[key] = clean_text(sections[key])
    return sections

def rank_resumes(jd_text, resumes):
    model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
    jd_embedding = model.encode([jd_text])[0]
    results = []
    for resume in resumes:
        resume_embedding = model.encode([resume['text']])[0]
        similarity = cosine_similarity([jd_embedding], [resume_embedding])[0][0]
        results.append({
            "Resume File": resume['name'],
            "Match (%)": round(similarity * 100, 2),
            "Skills": resume['sections'].get("skills", "Not Found"),
            "Education": resume['sections'].get("education", "Not Found"),
            "Experience": resume['sections'].get("experience", "Not Found")
        })
    return sorted(results, key=lambda x: x["Match (%)"], reverse=True)

# -------------------------------
# Streamlit Interface
# -------------------------------

st.title("🧠 Welcome to the AI-Based Resume Screening System")
st.write("This app analyzes and ranks resumes based on how well they match the provided Job Description.")
st.write("Upload a job description and resumes below to begin.")

jd_file = st.file_uploader("📄 Upload Job Description (.txt only)", type=["txt"])
resume_files = st.file_uploader("📁 Upload Resumes (.pdf or .docx)", type=["pdf", "docx"], accept_multiple_files=True)

if st.button("🚀 Start Screening"):
    if jd_file is None or not resume_files:
        st.warning("Please upload both Job Description and Resume files.")
    else:
        jd_text = jd_file.read().decode("utf-8")
        jd_text_clean = clean_text(jd_text)
        resumes = []
        for file in resume_files:
            with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
                tmp_file.write(file.read())
                tmp_path = tmp_file.name
            if file.name.endswith(".pdf"):
                raw_text = extract_text_pdf(tmp_path)
            elif file.name.endswith(".docx"):
                raw_text = extract_text_docx(tmp_path)
            else:
                continue
            clean_resume_text = clean_text(raw_text)
            sections = extract_resume_sections(raw_text)
            resumes.append({
                "name": file.name,
                "text": clean_resume_text,
                "sections": sections
            })
            try:
                os.remove(tmp_path)
            except Exception as e:
                print(f"Error deleting temp file {tmp_path}: {e}")
        results = rank_resumes(jd_text_clean, resumes)
        df = pd.DataFrame(results)
        st.markdown("---")
        st.success("✅ Resume screening completed successfully!")
        st.markdown("### 🔍 Resume Ranking & Details")
        st.dataframe(df)
        st.download_button("📥 Download Results", data=df.to_csv(index=False), file_name="ranked_resumes.csv", mime="text/csv")